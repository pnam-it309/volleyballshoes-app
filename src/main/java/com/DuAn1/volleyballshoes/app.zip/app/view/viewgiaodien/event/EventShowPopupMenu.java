package com.DuAn1.volleyballshoes.app.view.viewgiaodien.event;

import java.awt.Component;

public interface EventShowPopupMenu {

    public void showPopup(Component com);
}
