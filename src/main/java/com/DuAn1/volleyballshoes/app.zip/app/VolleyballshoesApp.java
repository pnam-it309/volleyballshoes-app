/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.DuAn1.volleyballshoes.app;

import com.DuAn1.volleyballshoes.app.view.viewdangnhap.main.MainDangNhap;

/**
 *
 * @author nickh
 */
public class VolleyballshoesApp {

    public static void main(String[] args) {
        new MainDangNhap().setVisible(true);
    }
}
